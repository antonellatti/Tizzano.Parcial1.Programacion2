package com.mycompany.segundoparcialtizzanoantonella;

import java.io.IOException;
import model.LibroDeRecetas;
import model.Receta;
import model.TipoReceta;

public class Main {

    public static void main(String[] args) {
        try {             
            // Crear un libro de recetas            
            LibroDeRecetas<Receta> libro = new LibroDeRecetas<>();             
            libro.agregar(new Receta(1, "Tarta de Verdura", "Abuela Rosa", TipoReceta.VEGETARIANA));             
            libro.agregar(new Receta(2, "Pollo al horno", "Juan Pérez", TipoReceta.PLATO_PRINCIPAL));             
            libro.agregar(new Receta(3, "Ensalada César", "Laura Ruiz", TipoReceta.ENTRADA));            
            libro.agregar(new Receta(4, "Brownie", "Chef Martín", TipoReceta.POSTRE));             
            libro.agregar(new Receta(5, "Pan sin gluten", "Lucía Gómez", TipoReceta.SIN_TACC));
            
            // Mostrar todas las recetas             
            System.out.println("Libro de recetas:");            
            libro.paraCadaElemento(System.out::println); 
             
            // Filtrar recetas por tipo VEGETARIANA             
            System.out.println("\nRecetas VEGETARIANAS:");             
            libro.filtrar(receta -> receta.getTipo() == TipoReceta.VEGETARIANA).forEach(System.out::println);
            
            // Filtrar recetas cuyo nombre contiene "tarta"             
            System.out.println("\nRecetas que contienen 'tarta':");             
            libro.filtrar(receta -> receta.getNombre().contains("tarta")).forEach(System.out::println);
                 
            // Ordenar recetas por ID (orden natural)            
            System.out.println("\nRecetas ordenadas por ID:");             
            libro.ordenarNatural();             
            libro.paraCadaElemento(System.out::println);
            
            // Ordenar recetas por nombre             
            System.out.println("\nRecetas ordenadas por nombre:");             
            libro.ordenarConComparator((r1, r2) -> r1.getNombre().compareTo(r2.getNombre())); 
            
            // Guardar el libro en archivo binario             
            libro.guardarEnArchivo("src/resources/recetas.dat"); 
            
            // Cargar el libro desde archivo binario            
            LibroDeRecetas<Receta> libroCargado = new LibroDeRecetas<>();             
            libroCargado.cargarDesdeArchivo("src/resources/recetas.dat");             
            System.out.println("\nRecetas cargadas desde archivo binario:");             
            libroCargado.paraCadaElemento(System.out::println);
            
            // Guardar el libro en archivo CSV             
            libro.guardarEnCSV("src/resources/recetas.csv"); 
            
            // Cargar el libro desde archivo CSV             
            libroCargado.cargarDesdeCSV("src/resources/recetas.csv", Receta::fromCSV);             
            System.out.println("\nRecetas cargadas desde archivo CSV:");             
            libroCargado.paraCadaElemento(System.out::println); 
            
        } catch (IOException | ClassNotFoundException e) {             
            System.err.println("Error: " + e.getMessage());
            
        }
    }
}