package model;

import java.io.Serializable;
import java.util.Objects;
import repository.CSVSerializable;

public class Receta implements Comparable<Receta>, CSVSerializable, Serializable{
    private int id;
    private String nombre;
    private String autor; 
    private TipoReceta tipo;

    public Receta(int id, String nombre, String autor, TipoReceta tipo) {
        this.id = id;
        this.nombre = nombre;
        this.autor = autor;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }

    public TipoReceta getTipo() {
        return tipo;
    }
    
    public static Receta fromCSV(String recetaCSV){
        Receta nuevaReceta = null;
        
        if(recetaCSV.endsWith("\n")){
            recetaCSV = recetaCSV.substring(0, recetaCSV.length() -1);
        }
        
        String[] valores = recetaCSV.split(",");
        if(valores.length == 4){
            int id = Integer.parseInt(valores[0]);
            String nombre = valores[1];
            String autor = valores[2];
            TipoReceta tipo = TipoReceta.valueOf(valores[3]);
            nuevaReceta = new Receta (id, nombre, autor, tipo);
        }
        return nuevaReceta;
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + autor + "," + tipo;
    }
    
    @Override
    public int compareTo(Receta r) {
        return Integer.compare(id, r.id);
    }
    
    @Override
    public String toString(){
        return "Receta numero: " + id + "de: " + nombre + "por: " + autor + "receta tipo: " + tipo;
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Receta r)){
            return false;
        }
        return r.id == id;
    }
    
}
