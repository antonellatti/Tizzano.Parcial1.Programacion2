package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import repository.CSVSerializable;

public class LibroDeRecetas <T extends CSVSerializable> implements Serializable{

    private static final long serialVersionUID = 1L;
    private List<T> recetario = new ArrayList<>();
    
    
    public void agregar(T receta){
        validarRepetida(receta);
        validarNull(receta);
        recetario.add(receta);
    }
    
    public void eliminar(int indice){
        validarIndice(indice);
        recetario.remove(indice);
    }
    
    public void obtener(int indice){
        validarIndice(indice);
        recetario.get(indice);
    }
    
    public List<T> filtrar(Predicate<T> criterio){
        List<T> filtrada = new ArrayList<>();
        for(T item : recetario){
            if(criterio.test(item)){
                filtrada.add(item);
            }
        }
        return filtrada;
    }
    
    public void ordenarNatural(){
        Collections.sort((List)recetario); 
    }
    
    public void ordenarConComparator(Comparator<T> comparador) {
        recetario.sort(comparador);
    }
    
    public void paraCadaElemento(Consumer<T> accion){
        for(T elemento : recetario){
            accion.accept(elemento);
        }
    }  
    
    private void validarIndice(int indice){
        if(indice < 0 || indice > recetario.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
        private void validarNull(T elem){
        if (elem == null){
            throw new NullPointerException("Elemento nulo");
        }
    }
    
    private void validarRepetida(T receta){
        if (recetario.contains(receta)) {
            throw new IllegalArgumentException("Receta repetida");
        }
    }
    
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream entrada = new ObjectOutputStream(new FileOutputStream(path))) {
            entrada.writeObject(this);
        }
    }
        
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException  {
        try (ObjectInputStream salida = new ObjectInputStream(new FileInputStream(path))) {
            LibroDeRecetas<T> cargado = (LibroDeRecetas<T>) salida.readObject();
            this.recetario = cargado.recetario;
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            for (T item : recetario) {
                bw.write(item.toCSV());
                bw.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String path, Function<String, T> fromCSV) throws IOException {
        recetario.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                recetario.add(fromCSV.apply(linea));
            }
        } 
    }
}