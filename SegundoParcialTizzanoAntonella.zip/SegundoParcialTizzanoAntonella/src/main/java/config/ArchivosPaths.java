package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public interface ArchivosPaths {
    
    static final String BASE = "src/resources";
    static final String FILE_CSV = "recetas.csv";
    static final String FILE_BIN = "recetas.bin";
    
    // csv
    public static Path getPathCSV(){
        return Paths.get(BASE, FILE_CSV);
    }
    public static String getPathCSVString(){
        return getPathCSV().toString();
    }
    // binari
    public static Path getPathBinario(){
        return Paths.get(BASE, FILE_BIN);
    }
    public static String getPathBinarioString(){
        return getPathBinario().toString();
    }  
}