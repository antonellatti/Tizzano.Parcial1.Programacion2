package tizzano.antonella.p1div322;

public class ArbolDecision extends Modelo implements Entrenable {
    private String criterioDivision;
    
    public ArbolDecision(String nombre, String laboratorio, TipoDatos tipoDatos, String criterioDivision) {
        super(nombre, laboratorio, tipoDatos);
        this.criterioDivision = criterioDivision;
    }
    @Override
    public String getDetalles() {
        return "Criterio de Divisiom: " + criterioDivision;
    }
    @Override
    public void entrenar() {
        System.out.println("Entrenamiendo inciiado");
    }
}
