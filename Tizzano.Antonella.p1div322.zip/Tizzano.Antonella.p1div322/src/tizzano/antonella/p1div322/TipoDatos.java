package tizzano.antonella.p1div322;

public enum TipoDatos {
    DATOS_NUMERICOS,
    DATOS_TEXTUALES
}