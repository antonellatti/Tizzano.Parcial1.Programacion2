package tizzano.antonella.p1div322;

public abstract class Modelo {
    private String nombreIdentificador;
    private String laboratorio;
    private TipoDatos tipoDatos;

    public Modelo(String nombre, String laboratorio, TipoDatos tipoDatos) {
        this.nombreIdentificador = nombre;
        this.laboratorio = laboratorio;
        this.tipoDatos = tipoDatos;
    }
    public String getNombre() {
        return nombreIdentificador;
    }
    public String getLaboratorio() {
        return laboratorio;
    }
    public TipoDatos getTipoDatos() {
        return tipoDatos;
    }
    public abstract String getDetalles();
    @Override
    public String toString() {
        return "Nombre del modelo: " + nombreIdentificador + ", Laboratorio: " + laboratorio + ", Tipo de Datos: " + tipoDatos;
    }
}