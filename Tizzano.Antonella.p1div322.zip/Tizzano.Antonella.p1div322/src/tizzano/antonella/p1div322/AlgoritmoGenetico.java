package tizzano.antonella.p1div322;

public class AlgoritmoGenetico extends Modelo {
    private double tasaMutacionIdeal;

    public AlgoritmoGenetico(String nombre, String laboratorio, TipoDatos tipoDatos, double tasaMutacion) {
        super(nombre, laboratorio, tipoDatos);
        this.tasaMutacionIdeal = tasaMutacion;
    }
    @Override
    public String getDetalles() {
        return "Tasa de Mutación Ideal: " + tasaMutacionIdeal + "%";
    }
}