package tizzano.antonella.p1div322;

public class RedNeuronal extends Modelo implements Entrenable {
    private int cantMaxCapas;

    public RedNeuronal(String nombre, String laboratorio, TipoDatos tipoDatos,int cantMaxCapas) {
        super(nombre, laboratorio, tipoDatos);
        this.cantMaxCapas = cantMaxCapas;
    }
    @Override
    public String getDetalles() {
        return "Cantidad máxima de capas: " + cantMaxCapas;
    }
    @Override
    public void entrenar() {
        System.out.println("Entrenamiendo inciiado");
    }
}