package tizzano.antonella.p1div322;
import java.util.*;

public class CentroIA {
    private List<Modelo> modelos = new ArrayList<>();

    public void agregarModelo(Modelo modelo) throws ExceptionModeloExistente {
        for (Modelo m : modelos) {
            if (m.getNombre().equals(modelo.getNombre()) &&
                m.getLaboratorio().equals(modelo.getLaboratorio())) {
                throw new ExceptionModeloExistente("Modelo ya existente en laboratorio.");
            }
        }
        modelos.add(modelo);
    }
    public void mostrarModelos() {
        if (modelos.isEmpty()) {
            System.out.println("No hay modelos aun.");
            return;
        }
        for (Modelo m : modelos) {
            System.out.println("Nombre: " + m.getNombre());
            System.out.println("Laboratorio: " + m.getLaboratorio());
            System.out.println("Tipo de Datos: " + m.getTipoDatos());
            System.out.println(m.getDetalles());
            System.out.println(" ............................ ");
        }
    }
    public void entrenarModelos() {
        for (Modelo m : modelos) {
            if (m instanceof Entrenable entrenable) {
                entrenable.entrenar();
            } else {
                System.out.println("El modelo " + m.getNombre() + " no es entrenable.");
            }
        }
    }
    public List<Modelo> filtrarPorTipoDatos(TipoDatos tipo) {
        List<Modelo> filtroTipoDatos = new ArrayList<>();
        for (Modelo m : modelos) {
            if (m.getTipoDatos() == tipo) {
                filtroTipoDatos.add(m);
            }
        }
        for (Modelo m : filtroTipoDatos) {
            System.out.println("Nombre: " + m.getNombre() + " - " + m.getDetalles());
        }
        return filtroTipoDatos;
    }
}