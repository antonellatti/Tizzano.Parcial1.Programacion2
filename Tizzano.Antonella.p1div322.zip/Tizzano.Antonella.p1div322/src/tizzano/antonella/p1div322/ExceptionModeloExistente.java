package tizzano.antonella.p1div322;

public class ExceptionModeloExistente extends RuntimeException{
    public ExceptionModeloExistente(String mensaje) {
        super(mensaje);
    }
}