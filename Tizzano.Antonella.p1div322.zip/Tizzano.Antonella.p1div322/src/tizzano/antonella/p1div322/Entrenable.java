package tizzano.antonella.p1div322;

public interface Entrenable {
    void entrenar();
}