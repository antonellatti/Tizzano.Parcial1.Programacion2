package tizzano.antonella.p1div322;

public class Main {

    public static void main(String[] args) {
        CentroIA CIA = new CentroIA();
        try {
            CIA.agregarModelo(new RedNeuronal("ClasificadorImagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 5));
            CIA.agregarModelo(new ArbolDecision("AD1", "Lab2", TipoDatos.DATOS_TEXTUALES, "entropía"));
            CIA.agregarModelo(new AlgoritmoGenetico("AG1", "Lab3", TipoDatos.DATOS_NUMERICOS, 0.05));
            CIA.agregarModelo(new RedNeuronal("RN2", "Lab2", TipoDatos.DATOS_TEXTUALES, 7));
            CIA.agregarModelo(new RedNeuronal("ClasificadorImagenes", "Lab1", TipoDatos.DATOS_NUMERICOS, 15));
        } catch (ExceptionModeloExistente e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println(".......MODELOS.......");
        CIA.mostrarModelos();

        System.out.println(".......ENTRENAMIENTOS.......");
        CIA.entrenarModelos();

        System.out.println(".......TIPO DE DATOS.......");
        CIA.filtrarPorTipoDatos(TipoDatos.DATOS_TEXTUALES);
    }
}